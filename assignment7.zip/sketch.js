// User config
// Framerate of simulation.
let FPS = 60;
// How long ripples should stay in frames at set framerate.
let rippleTime = 60;
// How quickly ripples should grow
let rippleInflate = 1;
// How thick ripples should be.
let rippleThickness = 5;

// Universal variables
var xPoints = [];
var yPoints = [];

function setup() {
    createCanvas(1280,720);
    colorMode(RGB,255,255,255,1);
    background(100,120,150,1);
    frameRate(FPS);
    ellipseMode(CENTER);
    angleMode(DEGREES);
    fill(100,120,150,1);
    for (var i = 0; i < rippleTime; i++) {
        xPoints[i] = width + 2000;
        yPoints[i] = height + 2000;
    }
    print(xPoints.length);
}

function draw() {
    background(100,120,150,1);
    fill(100,120,150,1);
    // Modify the table, moving everything up one space
    for (var i = rippleTime-1; i > 0; i--) {
        xPoints[i] = xPoints[i-1];
        yPoints[i] = yPoints[i-1];
    }
    // Ripples are only created if a key is held
    if (mouseIsPressed == true && abs(dist(mouseX,mouseY,pmouseX,pmouseY)) >= 3) {
        xPoints[0] = mouseX;
        yPoints[0] = mouseY;
    }
    // If mouse is not pressed or cursor is too slow, ripples are summoned off-screen
    else {
        xPoints[0] = width + 10000;
        yPoints[0] = height + 10000;
    }
    // Draw the ripples, generating older ones first so newer ones are on top
    for (var i = rippleTime; i > 0; i--) {
        let xTarget = xPoints[i];
        let yTarget = yPoints[i];
        stroke(77,92,115,1 - i/rippleTime);
        strokeWeight(rippleThickness);
        ellipse(xTarget,yTarget,10 + (i*rippleInflate),10 + (i*rippleInflate));
    }
    // Draw the lily pads
    strokeWeight(3);
    fill(78,193,85,1);
    stroke(68,168,74,1);
    arc(170,520,110,110,10,330,PIE);
    strokeWeight(2);
    fill(193,85,193,1);
    stroke(180,79,180,1);
    ellipse(140,525,30,30);
}