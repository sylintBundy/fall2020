let darkMode = false;
let fillLightness = 230;
let strokeLightness = 200;

function setup() {
    createCanvas(400,400);
    background(200);
    colorMode(RGB, 255, 255, 255, 1);
    rectMode(CORNER);
}

function draw() {
    // White keys: S, D, F, G, H, J, K, L
    // Black keys: E, R, Y, U, I
    // White Keys
    strokeWeight(1);
    stroke(strokeLightness,strokeLightness,strokeLightness,1);
    fill(fillLightness,fillLightness,fillLightness,1);
    let x = 0;
    for (i = 1; i <= 8; i++) {
        rect(x, 0, 50, 400);
        x += 50;
    }
    // Black Keys
    noStroke();
    fill(20,20,20,1);
    let x2 = 35
    for (i = 1; i <= 6; i++) {
        if (x2 != 135) {
            rect(x2, 0, 30, 250);
        }
        x2 += 50;
    }
    if (keyIsPressed) {
        if (key == 's') {
            fill(255,0,0,1);
            rect(0,0,50,400);
            fill(20,20,20,1);
            rect(35,0,30,250);
        }
        else if (key == 'd') {
            fill(0,0,255,1);
            rect(50,0,50,400);
            fill(20,20,20,1);
            rect(35,0,30,250);
            rect(85,0,30,250);
        }
        else if (key == 'f') {
            fill(255,255,0,1);
            rect(100,0,50,400);
            fill(20,20,20,1);
            rect(85,0,30,250);
        }
        else if (key == 'g') {
            fill(0,200,0,1);
            rect(150,0,50,400);
            fill(20,20,20,1);
            rect(185,0,30,250);
        }
        else if (key == 'h') {
            fill(150,0,255,1);
            rect(200,0,50,400);
            fill(20,20,20,1);
            rect(185,0,30,250);
            rect(235,0,30,250);
        }
        else if (key == 'j') {
            fill(0,255,0,1);
            rect(250,0,50,400);
            fill(20,20,20,1);
            rect(235,0,30,250);
            rect(285,0,30,250);
        }
        else if (key == 'k') {
            fill(255,150,0,1);
            rect(300,0,50,400);
            fill(20,20,20,1);
            rect(285,0,30,250);
        }
        else if (key == 'l') {
            fill(0,255,255,1);
            rect(350,0,50,400);
        }
        else if (key == 'e') {
            fill(75,75,75,1);
            rect(35,0,30,250);
        }
        else if (key == 'r') {
            fill(75,75,75,1);
            rect(85,0,30,250);
        }
        else if (key == 'y') {
            fill(75,75,75,1);
            rect(185,0,30,250);
        }
        else if (key == 'u') {
            fill(75,75,75,1);
            rect(235,0,30,250);
        }
        else if (key == 'i') {
            fill(75,75,75,1);
            rect(285,0,30,250);
        }
    }
}

function mouseClicked() {
    if (darkMode == false) {
        fillLightness = 100;
        strokeLightness = 40;
        darkMode = true;
    }
    else {
        fillLightness = 230;
        strokeLightness = 200;
        darkMode = false;
    }
}