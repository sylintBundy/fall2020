var drum;
var mic, capture, amp, osc, sinFreq, sinAmp, sinePlaying = false, middleSize = 0, drumFrame = 30;

function preload() {
    drum = loadSound("drum.wav")
}

function setup() {
    createCanvas(1280,720);
    ellipseMode(CENTER);
    mic = new p5.AudioIn();
    mic.start();
    inputAmp = new p5.Amplitude();
    inputAmp.setInput(mic);
    sine = new p5.SinOsc();
    capture = createCapture();
    capture.hide();
}

function draw() {
    background(240);
    noStroke();
    fill(180);
    image(capture, 214, 120, 853, 480);
    rect(214, 120, 853, 480);
    filter(GRAY);
    ellipse(100, 620, map(inputAmp.getLevel(), 0, 1, 50, 100), map(inputAmp.getLevel(), 0, 1, 50, 100));
    ellipse(1180, 620, map(inputAmp.getLevel(), 0, 1, 50, 100), map(inputAmp.getLevel(), 0, 1, 50, 100));
    if (sinePlaying == true) {
        sine.freq(map(mouseX, 0, width, 100, 1180));
        sine.amp(map(720 - mouseY, 0, height, 0, 1) * .25, 0.1);
        middleSize = map(720 - mouseY, 0, height, 0, 1);
    }
    ellipse(100, height/2, map(middleSize, 0, 1, 50, 100), map(middleSize, 0, 1, 50, 100));
    ellipse(1180, height/2, map(middleSize, 0, 1, 50, 100), map(middleSize, 0, 1, 50, 100));
    if (drumFrame <= 30) {
        drumFrame++
    }
    ellipse(100, 100, 100 - (drumFrame * 2), 100 - (drumFrame * 2));
    ellipse(1180, 100, 100 - (drumFrame * 2), 100 - (drumFrame * 2));
}

function mouseClicked() {
    if (sinePlaying == false) {
        sinePlaying = true;
        sine.start();
    }
    else {
        sinePlaying = false;
        sine.amp(0, 0.5);
        middleSize = 0;
    }
}

function keyPressed() {
    drumFrame = 0;
    drum.play();
}